﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace LabTask1.Models
{
    public class Student
    {
        public int Id { get; set; }
        [Required]
        [MaxLength(10, ErrorMessage = "Please Provide Your Name")]
        public string Name { get; set; }
        [Required]
        public DateTime Dob { get; set; }
        [Required]
        public int Credit { get; set; }
        [Required]
        [Range(0,4,ErrorMessage="CGPA must be 0 to 4")]
        public double CGPA { get; set; }
        [Required]
        [Range(1, double.PositiveInfinity, ErrorMessage = "Depertment value is Empty")]
        public int Dept_Id { get; set; }
    }
}