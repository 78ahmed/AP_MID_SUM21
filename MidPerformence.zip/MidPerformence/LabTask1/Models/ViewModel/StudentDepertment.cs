﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace LabTask1.Models.ViewModel
{
    public class StudentDepertment
    {
        public Student students { get; set; }
        public List<Depertment> depertments { get; set; }
        public StudentDepertment()
        {
            students = new Student();
            depertments = new List<Depertment>();
        }

    }
}