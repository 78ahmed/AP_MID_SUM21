﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web;

namespace LabTask1.Models.Database
{
    public class Depertments
    {
        SqlConnection conn;
        public Depertments(SqlConnection conn)
        {
            this.conn = conn;
        }
        void Insert(Admin a)
        {

        }
        public List<Depertment> GetAll()
        {
            var depertments = new List<Depertment>();
            string query = "select * from Depertments";
            SqlCommand cmd = new SqlCommand(query,conn);
            conn.Open();
            SqlDataReader reader = cmd.ExecuteReader();
            while (reader.Read())
            {
                Depertment d = new Depertment();
                d.Id = reader.GetInt32(reader.GetOrdinal("Id"));
                d.Name = reader.GetString(reader.GetOrdinal("Name"));

                depertments.Add(d);
            }
            conn.Close();
            return depertments;
        }
        void Get(int id)
        {

        }
        void Edit(Admin a)
        {

        }
        void Delete(int id)
        {

        }
    }
}