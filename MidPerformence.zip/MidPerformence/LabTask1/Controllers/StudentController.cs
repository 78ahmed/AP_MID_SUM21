﻿using LabTask1.Models;
using LabTask1.Models.Database;
using LabTask1.Models.ViewModel;
using System.Dynamic;
using System.Web.Mvc;

namespace LabTask1.Controllers
{
    public class StudentController : Controller
    {
        public ActionResult Index()
        {
            Database db = new Database();
            var students=db.Students.GetAll();
            return View(students);
        }
        public ActionResult Login()
        {          
            return View();
        }
        [HttpPost]
        public ActionResult Login(Admin a)
        {
            if (ModelState.IsValid)
            {
                //return View(a);
                return RedirectToAction("Dashboard");
            }
            else
            {
                return View();
            }

        }
        public ActionResult Dashboard()
        {
            return View();
        }
        public ActionResult CreateS()
        {
            Student s = new Student();
            //First Process
            //dynamic combodata = new ExpandoObject();
            //combodata.Student = s;
            //Database db = new Database();
            //combodata.Depertment = db.Depertments.GetAll();
            //return View(combodata);
            //Second Process create a ViewModel class 
            Database db = new Database();
            StudentDepertment combodata = new StudentDepertment();
            combodata.students = s;
            combodata.depertments= db.Depertments.GetAll();
            return View(combodata);
        }
        [HttpPost]
        public ActionResult CreateS(Student s)
        {
            if (ModelState.IsValid)
            {
                Database db = new Database();
                db.Students.Insert(s);
                return RedirectToAction("Index");
            }
            //Student s = new Student();
            Database database = new Database();
            StudentDepertment combodata = new StudentDepertment();
            combodata.students = s;
            combodata.depertments = database.Depertments.GetAll();
            return View(combodata);

        }
        public ActionResult Edit(int id)
        {
            Database db = new Database();
            var s = db.Students.Get(id);
            return View(s);
        }
        [HttpPost]
        public ActionResult Edit(Student s)
        {   
            Database db = new Database();
            db.Students.Update(s);
            return RedirectToAction("Index");
        }
        public ActionResult Delete(int id)
        {
            Database db = new Database();
            db.Students.Delete(id);
            return RedirectToAction("Index");
        }

    }
}